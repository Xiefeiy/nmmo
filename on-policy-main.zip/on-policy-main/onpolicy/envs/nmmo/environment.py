from argparse import Namespace
import math
import random
import numpy as np
from gym import spaces
import nmmo
import pufferlib
import pufferlib.emulation
from onpolicy.envs.nmmo.leader_board import StatPostprocessor, calculate_entropy

class Config(nmmo.config.Default):
    """Configuration for Neural MMO."""

    def __init__(self, args: Namespace):
        super().__init__()

        self.PROVIDE_ACTION_TARGETS = True
        self.PROVIDE_NOOP_ACTION_TARGET = True
        self.MAP_FORCE_GENERATION = False
        self.PLAYER_N = args.num_agents
        self.PLAYERS = [self.PLAYERS[0] for i in range(8)]
        self.HORIZON = args.max_episode_length
        self.MAP_N = args.num_maps
        self.PLAYER_DEATH_FOG = args.death_fog_tick
        self.PATH_MAPS = f"{args.maps_path}/{args.map_size}/"
        self.MAP_CENTER = args.map_size
        self.NPC_N = args.num_npcs
        self.CURRICULUM_FILE_PATH = args.tasks_path
        self.TASK_EMBED_DIM = args.task_size
        self.RESOURCE_RESILIENT_POPULATION = args.resilient_population

        self.COMMUNICATION_SYSTEM_ENABLED = False

        self.COMBAT_SPAWN_IMMUNITY = args.spawn_immunity


class Postprocessor(StatPostprocessor):
    def __init__(self, env, is_multiagent, agent_id,
        eval_mode=False,
        early_stop_agent_num=0,
        sqrt_achievement_rewards=False,
        heal_bonus_weight=0,
        meander_bonus_weight=0,
        explore_bonus_weight=0,
        clip_unique_event=3,
    ):
        super().__init__(env, agent_id, eval_mode)
        self.early_stop_agent_num = early_stop_agent_num
        self.sqrt_achievement_rewards = sqrt_achievement_rewards
        self.heal_bonus_weight = heal_bonus_weight
        self.meander_bonus_weight = meander_bonus_weight
        self.explore_bonus_weight = explore_bonus_weight
        self.clip_unique_event = clip_unique_event
        self.num_agents = 0

    def reset(self, obs):
        '''Called at the start of each episode'''
        super().reset(obs)

    @property
    def observation_space(self):
        '''If you modify the shape of features, you need to specify the new obs space'''
        return super().observation_space

    """
    def observation(self, obs):
        '''Called before observations are returned from the environment

        Use this to define custom featurizers. Changing the space itself requires you to
        define the observation space again (i.e. Gym.spaces.Dict(gym.spaces....))
        '''
        return obs

    def action(self, action):
        '''Called before actions are passed from the model to the environment'''
        return action
    """

    def reward_done_info(self, reward, done, info):
        '''Called on reward, done, and info before they are returned from the environment'''
        self.num_agents = max(self.num_agents, len(self.env.agents))

        # Stop early if there are too few agents generating the training data
        # if len(self.env.agents) < self.early_stop_agent_num:        # modified from "<=" to "<", 2024/07/18
        #     # print(f"{len(self.env.agents)} <= {self.early_stop_agent_num}")
        #     done = True
        if len(self.env.agents) < min(self.num_agents // 4, 8):     # added 2024/07/18
            done = True

        reward, done, info = super().reward_done_info(reward, done, info)

        # Default reward shaper sums team rewards.
        # Add custom reward shaping here.

        # Add "Healing" score based on health increase and decrease due to food and water
        healing_bonus = 0
        if self.agent_id in self.env.realm.players:
            if self.env.realm.players[self.agent_id].resources.health_restore > 0:
                healing_bonus = self.heal_bonus_weight

        # Add meandering bonus to encourage moving to various directions
        meander_bonus = 0
        if len(self._last_moves) > 5:
          move_entropy = calculate_entropy(self._last_moves[-8:])  # of last 8 moves
          meander_bonus = self.meander_bonus_weight * (move_entropy - 1)

        # Unique event-based rewards, similar to exploration bonus
        # The number of unique events are available in self._curr_unique_count, self._prev_unique_count
        if self.sqrt_achievement_rewards:
            explore_bonus = math.sqrt(self._curr_unique_count) - math.sqrt(self._prev_unique_count)
        else:
            explore_bonus = min(self.clip_unique_event,
                                self._curr_unique_count - self._prev_unique_count)
        explore_bonus *= self.explore_bonus_weight

        reward = reward + explore_bonus + healing_bonus + meander_bonus

        return reward, done, info


def make_env_creator(args: Namespace):
    # TODO: Max episode length
    def env_creator():
        """Create an environment."""
        env = nmmo.Env(Config(args))
        env = pufferlib.emulation.PettingZooPufferEnv(env,
            postprocessor_cls=Postprocessor,
            postprocessor_kwargs={
                'eval_mode': args.eval_mode,
                'early_stop_agent_num': args.early_stop_agent_num,
                'sqrt_achievement_rewards': args.sqrt_achievement_rewards,
                'heal_bonus_weight': args.heal_bonus_weight,
                'meander_bonus_weight': args.meander_bonus_weight,
                'explore_bonus_weight': args.explore_bonus_weight,
            },
        )
        return env
    return env_creator



class NmmoEnvWrapper(object):
    """
    Wrapper for Neural MMO environment.
    """
    def __init__(self, nmmo_env, args):
        self.num_agents = args.team_num * args.member_num
        self.env = nmmo_env
        
        self.max_steps = 1024
        self.share_reward = True
        self.action_space = []
        self.observation_space = []
        self.share_observation_space = []

        # print(f"self.env.possible_agents == {self.env.possible_agents}")            # [1, 2, 3, ..., 64]
        # print(f"self.env.action_space == {self.env.action_space}")                  # <bound method PettingZooPufferEnv.action_space of <pufferlib.emulation.PettingZooPufferEnv object at 0x7f341c35a5b0>>
        # print(f"self.env.observation_space == {self.env.observation_space}")        # <bound method PettingZooPufferEnv.observation_space of <pufferlib.emulation.PettingZooPufferEnv object at 0x7f341c35a5b0>>
        # print(f"self.env.action_space() == {self.env.action_space(1)}")             # MultiDiscrete([   3  101 1025   13   13  101   99  101    5   13   99   13])
        # print(f"self.env.observation_space() == {self.env.observation_space(64)}")  # Box(-3.4028234663852886e+38, 3.4028234663852886e+38, (26035,), float64)

        if self.num_agents == 1:
            self.action_space.append(self.env.action_space(1))
            self.observation_space.append(self.env.observation_space(1))
            self.share_observation_space.append(self.env.observation_space(1))
        else:
            # for idx in range(self.num_agents):
            #     self.action_space.append(spaces.Discrete(
            #         n=self.env.action_space[idx].n
            #     ))
            #     self.observation_space.append(spaces.Box(
            #         low=self.env.observation_space.low[idx],
            #         high=self.env.observation_space.high[idx],
            #         shape=self.env.observation_space.shape[1:],
            #         dtype=self.env.observation_space.dtype
            #     ))
            #     self.share_observation_space.append(spaces.Box(
            #         low=self.env.observation_space.low[idx],
            #         high=self.env.observation_space.high[idx],
            #         shape=self.env.observation_space.shape[1:],
            #         dtype=self.env.observation_space.dtype
            #     ))
            for idx in range(self.num_agents):
                self.action_space.append(
                    self.env.action_space(idx + 1)
                )
                self.observation_space.append(
                    self.env.observation_space(idx + 1)
                )
                self.share_observation_space.append(
                    self.env.observation_space(idx + 1)
                )


    def reset(self):
        obs = self.env.reset()
        obs = self._obs_wrapper(obs)
        return obs

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        obs = self._obs_wrapper(obs)
        reward = self._reward_wrapper(reward)
        # print(f"[Debug Info] np.sum(reward) == {np.sum(reward)}")
        
        if self.share_reward:
            # global_reward = np.sum(reward)
            global_reward = np.mean(reward)
            reward = [[global_reward]] * self.num_agents
        done = self._done_wrapper(done)
        info = self._info_wrapper(info)
        return obs, reward, done, info

    def seed(self, seed=None):
        if seed is None:
            random.seed(1)
        else:
            random.seed(seed)

    def close(self):
        # self.env.close()
        pass

    def _obs_wrapper(self, obs):
        if self.num_agents == 1:
            raise NotImplementedError
        else:
            _obs = []
            for j in range(self.num_agents):
                _obs.append(np.array(obs[j + 1]))
            return _obs
    
    def _reward_wrapper(self, reward):
        if self.num_agents == 1:
            raise NotImplementedError
        else:
            _reward = []
            for j in range(self.num_agents):
                _reward.append(reward[j + 1])
            return np.array(_reward)

    def _done_wrapper(self, done):
        if self.num_agents == 1:
            raise NotImplementedError
        else:
            _done = []
            for j in range(self.num_agents):
                _done.append(done[j + 1])
            return _done

    def _info_wrapper(self, info):
        # state = self.env.unwrapped.observation()
        # info.update(state[0])
        # info["max_steps"] = self.max_steps
        # info["active"] = np.array([state[i]["active"] for i in range(self.num_agents)])
        # info["designated"] = np.array([state[i]["designated"] for i in range(self.num_agents)])
        # info["sticky_actions"] = np.stack([state[i]["sticky_actions"] for i in range(self.num_agents)])
        return info
