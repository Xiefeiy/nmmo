import time
import numpy as np
import torch
from onpolicy.runner.shared.base_runner import Runner
import wandb
import imageio
from tqdm import tqdm

def _t2n(x):
    return x.detach().cpu().numpy()

class NMMORunner(Runner):
    """Runner class to perform training, evaluation. and data collection for the MPEs. See parent class for details."""
    def __init__(self, config):
        super(NMMORunner, self).__init__(config)

    def run(self):
        def check_any_true(lst):
            for i in range(len(lst)):
                if lst[i]:
                    return True
            return False
        
        def check_any_false(lst):
            for i in range(len(lst)):
                if not lst[i]:
                    return False
            return True
        
        self.warmup()   

        start = time.time()
        episodes = int(self.num_env_steps) // self.episode_length // self.n_rollout_threads
        total_num_steps = 0

        for episode in tqdm(range(episodes)):
            if self.use_linear_lr_decay:
                self.trainer.policy.lr_decay(episode, episodes)

            # for step in range(self.episode_length):
            episode_done_each_thread_list = [False for _ in range(self.n_rollout_threads)]
            step_each_thread_list = [0 for _ in range(self.n_rollout_threads)]
            step = 0
            sum_rewards_lst = []
            while not check_any_true(episode_done_each_thread_list):
                # Sample actions
                values, actions, action_log_probs, rnn_states, rnn_states_critic, actions_env = self.collect(step)
                    
                # Obser reward and next obs
                obs, rewards, dones, infos = self.envs.step(actions_env)
                # print(f"[Debug Info] obs.shape = {obs.shape}")              # [Debug Info] obs.shape = (NUM_TREADS=2, num_agents=8, 26035)
                # print(f"[Debug Info] rewards.shape = {rewards.shape}")      # [Debug Info] rewards.shape = (NUM_TREADS=2, num_agents=8, 1)  dtype=float32
                # print(f"[Debug Info] dones.shape = {dones.shape}")          # [Debug Info] dones.shape = (NUM_TREADS=2, num_agents=8)       dtype=bool
                # print(f"[Debug Info] type(infos) == {type(infos)}")         # [Debug Info] type(infos) == <class 'tuple'>
                # print(f"[Debug Info] dones == {dones}")

                # print(f"[Debug Info] np.sum(rewards) == {np.sum(rewards)}")
                sum_rewards = np.sum(rewards)
                sum_rewards_lst.append(sum_rewards)

                data = obs, rewards, dones, infos, values, actions, action_log_probs, rnn_states, rnn_states_critic

                # insert data into buffer
                self.insert(data)

                step += 1
                for thread_idx in range(self.n_rollout_threads):
                    step_each_thread_list[thread_idx] += 1
                    dones_mask = dones[thread_idx].copy()
                    # print(f"[Debug Info] dones_mask == {dones_mask}")
                    episode_done_this_thread = check_any_false(dones_mask)
                    # print(f">>>>  episode_done_this_thread == {episode_done_this_thread}")
                    # print(f"self.episode_length == {self.episode_length}")
                    if step >= self.episode_length:
                        episode_done_this_thread  = True
                    # print(f">>>>  episode_done_this_thread == {episode_done_this_thread}")
                    episode_done_each_thread_list[thread_idx] = episode_done_this_thread
                
                # print(f"[Debug Info] episode_done_each_thread_list == {episode_done_each_thread_list}")
                
            sum_over_sum_rewards = np.sum(np.array(sum_rewards_lst))
            # print(f"[Debug Info] sum_over_sum_rewards == {sum_over_sum_rewards}")


            # compute return and update network
            self.compute()
            train_infos = self.train()
            # print(f"[Debug Info] train_infos == {train_infos}")
            train_infos["episode_length"] = step
            print(f"episode_length: {step}")
            
            # post process
            # total_num_steps = (episode + 1) * self.episode_length * self.n_rollout_threads
            total_num_steps += step
            
            # save model
            if (episode % self.save_interval == 0 or episode == episodes - 1):
                self.save()

            # log information
            if episode % self.log_interval == 0:
                end = time.time()
                print(" Env {} Algo {} Exp {} updates {}/{} episodes, total num timesteps {}/{}, FPS {}."
                        .format(self.env_name,
                                self.algorithm_name,
                                self.experiment_name,
                                episode,
                                episodes,
                                total_num_steps,
                                self.num_env_steps,
                                int(total_num_steps / (end - start))))

                # train_infos["average_episode_rewards"] = np.mean(self.buffer.rewards) * self.episode_length     # should not [* self.episode_length]
                # print("average episode rewards is {}".format(train_infos["average_episode_rewards"]))
                train_infos["episode_reward_avg_over_each_agent"] = sum_over_sum_rewards / self.num_agents
                print("episode_reward_avg_over_each_agent is {}".format(train_infos["episode_reward_avg_over_each_agent"]))
                self.log_train(train_infos, total_num_steps)

            # eval
            if episode % self.eval_interval == 0 and self.use_eval:
                self.eval(total_num_steps)

    def warmup(self):
        # reset env
        obs = self.envs.reset()
        # print(f"[Debug Info] obs.shape == {obs.shape}")     # [Debug Info] obs.shape == (2, 8, 26035)

        # replay buffer
        if self.use_centralized_V:
            raise NotImplementedError
            share_obs = obs.reshape(self.n_rollout_threads, -1)
            print(f"[Debug Info] share_obs.shape == {share_obs.shape}")
            share_obs = np.expand_dims(share_obs, 1).repeat(self.num_agents, axis=1)
        else:
            share_obs = obs
        # print(f"[Debug Info] share_obs.shape == {share_obs.shape}")     # [Debug Info] share_obs.shape == (2, 8, 26035)

        self.buffer.share_obs[0] = share_obs.copy()
        self.buffer.obs[0] = obs.copy()

    @torch.no_grad()
    def collect(self, step):
        self.trainer.prep_rollout()
        value, action, action_log_prob, rnn_states, rnn_states_critic \
            = self.trainer.policy.get_actions(np.concatenate(self.buffer.share_obs[step]),
                            np.concatenate(self.buffer.obs[step]),
                            np.concatenate(self.buffer.rnn_states[step]),
                            np.concatenate(self.buffer.rnn_states_critic[step]),
                            np.concatenate(self.buffer.masks[step]))
        # [self.envs, agents, dim]
        values = np.array(np.split(_t2n(value), self.n_rollout_threads))
        actions = np.array(np.split(_t2n(action), self.n_rollout_threads))
        action_log_probs = np.array(np.split(_t2n(action_log_prob), self.n_rollout_threads))
        rnn_states = np.array(np.split(_t2n(rnn_states), self.n_rollout_threads))
        rnn_states_critic = np.array(np.split(_t2n(rnn_states_critic), self.n_rollout_threads))
        # print(f"[Debug Info] actions.shape == {actions.shape}")     # (NUM_THREADS=2, num_agents=8, action_dim=12)

        """
        # rearrange action
        rearrange_actions = {}
        for j in range(self.num_agents):
            team_idx = j // 8
            agent_idx = j % 8
            rearrange_actions[j+1] = actions[j]

        action_mask = [0, 1, 8, 11]         # temporarily, we only use some dimensions of the actions
        def action_process(raw_actions):
            new_actions = {}
            for k in raw_actions.keys():
                action = raw_actions[k]
                new_action = np.array([0,0,0,0,0,0,0,0,0,0,0,0],dtype=np.int32)
                for i in range(len(action_mask)):
                    new_action[action_mask[i]] = action[i]
                new_actions[k] = new_action
            return new_actions
        actions_env = action_process(rearrange_actions)
        """
        action_mask = [0, 1, 8, 11]         # temporarily, we only use some dimensions of the actions
        mask_matrix = np.array([1, 1, 0, 0, 
                            0, 0, 0, 0, 
                            1, 0, 0, 1])
        mask_matrix = mask_matrix[np.newaxis, np.newaxis, :]
        # print(f"[Debug Info] _matrix.shape == {_matrix.shape} ")
        actions_rearrange = actions * mask_matrix
        # print(f"[Debug Info] actions_rearrange.shape == {actions_rearrange.shape} ")
        actions_env = []
        for thread_idx in range(actions_rearrange.shape[0]):
            _actions_in_a_certain_thread = actions_rearrange[thread_idx]    # (num_agents=8, action_dim=12)
            _dict = {}
            for j in range(self.num_agents):
                _dict[j+1] = _actions_in_a_certain_thread[j]        # (12,)
            actions_env.append(_dict)


        return values, actions, action_log_probs, rnn_states, rnn_states_critic, actions_env

    def insert(self, data):
        obs, rewards, dones, infos, values, actions, action_log_probs, rnn_states, rnn_states_critic = data

        rnn_states[dones == True] = np.zeros(((dones == True).sum(), self.recurrent_N, self.hidden_size), dtype=np.float32)
        rnn_states_critic[dones == True] = np.zeros(((dones == True).sum(), *self.buffer.rnn_states_critic.shape[3:]), dtype=np.float32)
        masks = np.ones((self.n_rollout_threads, self.num_agents, 1), dtype=np.float32)
        masks[dones == True] = np.zeros(((dones == True).sum(), 1), dtype=np.float32)

        if self.use_centralized_V:
            share_obs = obs.reshape(self.n_rollout_threads, -1)
            share_obs = np.expand_dims(share_obs, 1).repeat(self.num_agents, axis=1)
        else:
            share_obs = obs

        self.buffer.insert(share_obs, obs, rnn_states, rnn_states_critic, actions, action_log_probs, values, rewards, masks)

    @torch.no_grad()
    def eval(self, total_num_steps):
        eval_episode_rewards = []
        eval_obs = self.eval_envs.reset()

        eval_rnn_states = np.zeros((self.n_eval_rollout_threads, *self.buffer.rnn_states.shape[2:]), dtype=np.float32)
        eval_masks = np.ones((self.n_eval_rollout_threads, self.num_agents, 1), dtype=np.float32)

        for eval_step in range(self.episode_length):
            self.trainer.prep_rollout()
            eval_action, eval_rnn_states = self.trainer.policy.act(np.concatenate(eval_obs),
                                                np.concatenate(eval_rnn_states),
                                                np.concatenate(eval_masks),
                                                deterministic=True)
            eval_actions = np.array(np.split(_t2n(eval_action), self.n_eval_rollout_threads))
            eval_rnn_states = np.array(np.split(_t2n(eval_rnn_states), self.n_eval_rollout_threads))

            # rearrange action
            rearrange_actions = {}
            for j in range(self.num_agents):
                team_idx = j // 8
                agent_idx = j % 8
                rearrange_actions[j+1] = eval_actions[j]

            action_mask = [0, 1, 8, 11]         # temporarily, we only use some dimensions of the actions
            def action_process(raw_actions):
                new_actions = {}
                for k in raw_actions.keys():
                    action = raw_actions[k]
                    new_action = np.array([0,0,0,0,0,0,0,0,0,0,0,0],dtype=np.int32)
                    for i in range(len(action_mask)):
                        new_action[action_mask[i]] = action[i]
                    new_actions[k] = new_action
                return new_actions
            eval_actions_env = action_process(rearrange_actions)

            # Obser reward and next obs
            eval_obs, eval_rewards, eval_dones, eval_infos = self.eval_envs.step(eval_actions_env)
            eval_episode_rewards.append(eval_rewards)

            eval_rnn_states[eval_dones == True] = np.zeros(((eval_dones == True).sum(), self.recurrent_N, self.hidden_size), dtype=np.float32)
            eval_masks = np.ones((self.n_eval_rollout_threads, self.num_agents, 1), dtype=np.float32)
            eval_masks[eval_dones == True] = np.zeros(((eval_dones == True).sum(), 1), dtype=np.float32)

        eval_episode_rewards = np.array(eval_episode_rewards)
        eval_env_infos = {}
        eval_env_infos['eval_average_episode_rewards'] = np.sum(np.array(eval_episode_rewards), axis=0)
        eval_average_episode_rewards = np.mean(eval_env_infos['eval_average_episode_rewards'])
        print("eval average episode rewards of agent: " + str(eval_average_episode_rewards))
        # self.log_env(eval_env_infos, total_num_steps)

    @torch.no_grad()
    def render(self):
        assert False, "Neural MMO does not support rendering!"
        """Visualize the env."""
        envs = self.envs
        
        all_frames = []
        for episode in range(self.all_args.render_episodes):
            obs = envs.reset()
            if self.all_args.save_gifs:
                image = envs.render('rgb_array')[0][0]
                all_frames.append(image)
            else:
                envs.render('human')

            rnn_states = np.zeros((self.n_rollout_threads, self.num_agents, self.recurrent_N, self.hidden_size), dtype=np.float32)
            masks = np.ones((self.n_rollout_threads, self.num_agents, 1), dtype=np.float32)
            
            episode_rewards = []
            
            for step in range(self.episode_length):
                calc_start = time.time()

                self.trainer.prep_rollout()
                action, rnn_states = self.trainer.policy.act(np.concatenate(obs),
                                                    np.concatenate(rnn_states),
                                                    np.concatenate(masks),
                                                    deterministic=True)
                actions = np.array(np.split(_t2n(action), self.n_rollout_threads))
                rnn_states = np.array(np.split(_t2n(rnn_states), self.n_rollout_threads))

                if envs.action_space[0].__class__.__name__ == 'MultiDiscrete':
                    for i in range(envs.action_space[0].shape):
                        uc_actions_env = np.eye(envs.action_space[0].high[i]+1)[actions[:, :, i]]
                        if i == 0:
                            actions_env = uc_actions_env
                        else:
                            actions_env = np.concatenate((actions_env, uc_actions_env), axis=2)
                elif envs.action_space[0].__class__.__name__ == 'Discrete':
                    actions_env = np.squeeze(np.eye(envs.action_space[0].n)[actions], 2)
                else:
                    raise NotImplementedError

                # Obser reward and next obs
                obs, rewards, dones, infos = envs.step(actions_env)
                episode_rewards.append(rewards)

                rnn_states[dones == True] = np.zeros(((dones == True).sum(), self.recurrent_N, self.hidden_size), dtype=np.float32)
                masks = np.ones((self.n_rollout_threads, self.num_agents, 1), dtype=np.float32)
                masks[dones == True] = np.zeros(((dones == True).sum(), 1), dtype=np.float32)

                if self.all_args.save_gifs:
                    image = envs.render('rgb_array')[0][0]
                    all_frames.append(image)
                    calc_end = time.time()
                    elapsed = calc_end - calc_start
                    if elapsed < self.all_args.ifi:
                        time.sleep(self.all_args.ifi - elapsed)
                else:
                    envs.render('human')

            print("average episode rewards is: " + str(np.mean(np.sum(np.array(episode_rewards), axis=0))))

        if self.all_args.save_gifs:
            imageio.mimsave(str(self.gif_dir) + '/render.gif', all_frames, duration=self.all_args.ifi)
